// models/sourcefiles.js
const mongoose = require('mongoose');

const AIN0001TargetFilesSchema = new mongoose.Schema({
  filename: String,
  FileSize: String,
  Date: String,
  Time: String,
  fileStatus: String,
  msg: String,
  // Other fields if needed
});

const AIN0001TargetFiles = mongoose.model('ain0001targetfiles', AIN0001TargetFilesSchema);

module.exports = AIN0001TargetFiles;