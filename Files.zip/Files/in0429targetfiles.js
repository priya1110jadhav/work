const fs = require('fs');
const { Client } = require('ssh2');
const moment = require('moment');
const mongoose = require('mongoose');
const axios = require('axios');
const cron = require('node-cron');
const InitiateMongoServer = require('./envUtils/mongoDb.js')

const IN0429TargetFiles = require('./models/IN0429TargetFilesModel.js');

async function FileProcess(){
  await InitiateMongoServer();
const connSettings = {
  host: 'ITSUSRALSP00875.jnj.com',
  port: 22,
  username: 'btbcanftp',
  password: 'Welcome2016#',
};

const remotePaths = [
  '/data/interface/BPUCLNT400/in/IN0429/',
  '/data/interface/BPUCLNT400/archive/IN0429/',
];

const conn = new Client();
const dataToInsert = [];

// mongoose.connect('mongodb://localhost:27017/processFlow', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

const checkTime = (file) => {
 
  const fileTime = moment(file.Time, 'HH:mm:ss');
  let result = 'Delayed'; // Default result

  if (file.filename.includes('IN0429_BtBECC_908')) {
    // IN0429_BtBECC_908 files come between 10:45 am to 11 am
    const startTime = moment().set({ hour: 1, minute: 30, second: 0 });
    const endTime = moment().set({ hour: 2, minute: 30, second: 0 });

    if (fileTime.isBetween(startTime, endTime) || fileTime.isBefore(endTime)) {
      result = 'Success';
    }
  } 
  return result;
};
async function processFilesInPath(remotePath) {
  try {
    await new Promise((resolve, reject) => {
      conn.sftp((err, sftp) => {
        if (err) reject(err);

        sftp.readdir(remotePath, (err, list) => {
          if (err) reject(err);

          for (const file of list) {
            if (file.filename.startsWith('IN0429_BtBECC_908')) {
              var filename = '';
              var filesize = '';
              var date = '';
              var time = '';
              const timeRegex = /\b(\d{2}:\d{2})\b/;
              const match = file.longname.match(timeRegex);
              if (match) {
                time = match[1];
              }

              filename = file.filename.substring(0, 36);
              filesize = (file.attrs.size / 1024).toFixed(2);

              timestamp = file.filename.substring(18, 32);
              date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');

              var fileStatus = checkTime({filename: filename,
                FileSize: filesize,
                Date: date,
                Time: time,});
               
        

              if (filename) {
                dataToInsert.push({
                  filename: filename,
                  FileSize: filesize,
                  Date: date,
                  Time: time,
                  fileStatus: fileStatus,
                  msg: null,
                });
              }
            }
          }

          resolve();
        });
      });
    });
  } catch (error) {
    console.error(`Error reading directory ${remotePath}: ${error.message}`);
  }
}

async function fetchDataAndUpdate (){
  let config = {
    method: 'get',
    maxBodyLength: Infinity,
    url: 'https://btbmboxispv.na.jnj.com:5503/rest/SG001_SDX_UI/http/SG001_MBOX_UI.api2.documents:selectDocuments?^$json=%7B%22projectId%22:%2220160127171004865996326469373749%22,%22hours%22:%22-744%22,%22fromDateTime%22:null,%22toDateTime%22:null,%22processed%22:null,%22fileDefinitionId%22:null,%22fileDefinitionName%22:null,%22filename%22:%22*IN0429*%22,%22hostid%22:null,%22minimumNumberOfTries%22:0,%22offset%22:0,%22limit%22:20,%22sortModel%22:%5B%7B%22sort%22:%22desc%22,%22colId%22:%22RECEIVED_DATETIME%22%7D%5D%7D',
    headers: { 
      'Accept': 'application/json, text/plain, */*', 
      'Accept-Language': 'en-US,en;q=0.9', 
      'Authorization': 'Basic cGphZGhhMjk6UGlseWEpKDo=', 
      'Connection': 'keep-alive', 
      'Cookie': 'ssnid=4d5cde14ee964db284ef40d2342b8423; ssnid=58d607bbac7e4d6e99c40c0628c8a726', 
      'If-Modified-Since': 'Mon, 18 Dec 2023 12:22:33 GMT', 
      'If-None-Match': '"sI9BwZlkJu/tntmija46rmPjFQ0T3fogbKFLG99qzCI="', 
      'Referer': 'https://btbmboxispv.na.jnj.com:5503/SG001_MBOX_UI/', 
      'Sec-Fetch-Dest': 'empty', 
      'Sec-Fetch-Mode': 'cors', 
      'Sec-Fetch-Site': 'same-origin', 
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 
      'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"', 
      'sec-ch-ua-mobile': '?0', 
      'sec-ch-ua-platform': '"Windows"'
    }
  };
    
      try {
        const response = await axios.request(config);
        const resultsArray = response.data.results;
        
        // Filter only the files starting with 'IN0429_BtBECC_908'
        const filteredResults = resultsArray.filter(({ FILENAME }) => FILENAME.startsWith('IN0429_BtBECC_908'));
        
        // Create the selectedResults array
        const selectedResults = filteredResults.map(({ FILENAME, MSG }) => ({
          filename: FILENAME,
          msg: MSG,
        })); 
    
        // Iterate through selectedResults
        for (const entry of selectedResults) {
          // Check if the entry already exists in the collection
          const existingEntry = await IN0429TargetFiles.findOne({ filename: entry.filename });
          
      
         
          
            // If the entry exists and msg is not present, update the 'msg' field
            if (existingEntry.msg === null) {
              
              await IN0429TargetFiles.updateOne({ filename: entry.filename }, { msg: entry.msg });
             
            }
          
        }
    
        console.log('Database msg operation completed.');
      } catch (error) {
        console.log(error);
      }
}

let newInsertions = 0;
let skippedEntries = 0;

conn.on('ready', async function () {
  // Loop through each remote path
  for (const remotePath of remotePaths) {
    await processFilesInPath(remotePath);
  }

  // Insert data into the MongoDB collection
  try {
    for (const entry of dataToInsert) {
      // Check if the entry already exists in the collection
      const existingEntry = await IN0429TargetFiles.findOne({ filename: entry.filename });
      // await IN0429TargetFiles.updateOne({ filename: entry.filename }, { $set: { fileStatus: entry.fileStatus } });

      
      if (!existingEntry) {
        // If the entry does not exist, insert it into the collection
        await IN0429TargetFiles.create(entry);
        
      } 
    }
    await fetchDataAndUpdate();

  } catch (error) {
    console.error(`Error inserting data into MongoDB: ${error.message}`);
  }

  conn.end();
  
  console.log('Connections closed successfully.');
});

conn.connect(connSettings);
}
FileProcess();
// // Schedule the cron job to run daily at 5 pm (17:00)
// cron.schedule('6 12 * * *', async () => {
//   console.log('Running the cron job at 11 am...');
//   await FileProcess();
// });

// // Schedule the cron job to run at 3 pm
// cron.schedule('32 12 * * *', () => {
//   console.log('Running the cron job at 3 pm...');
//   FileProcess();
// });

// // Schedule the cron job to run at 9 pm
// cron.schedule('0 21 * * *', () => {
//   console.log('Running the cron job at 9 pm...');
//   FileProcess();
// });