// models/sourcefiles.js
const mongoose = require('mongoose');

const AIN0001SourceFilesSchema = new mongoose.Schema({
  filename: String,
  FileSize: String, 
  Date: String,
  Time: String,
});

const AIN0001SourceFiles = mongoose.model('ain0001sourcefiles', AIN0001SourceFilesSchema);

module.exports = AIN0001SourceFiles;