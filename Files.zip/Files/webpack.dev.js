const path = require("path");
const nodeExternals = require('webpack-node-externals')

module.exports = {
  entry: "./index.js",
  mode: "development",
  target:"node",
  module: {
    rules: [
      {
        exclude: /(node_modules)/,
        test: /\.(jsx)$/i,
        // loader: "babel-loader"
        use: "babel-loader"
      }
    ]
  },
  output: {
    path: path.resolve(__dirname, "dist-server"),
    publicPath:'/',
    filename:'[name].js',
    // clean:true
  },
  // externals: [nodeExternals()],
  plugins: []
};