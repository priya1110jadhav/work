const fs = require('fs');
const { Client } = require('ssh2');
const moment = require('moment');
const mongoose = require('mongoose');
const cron = require('node-cron');
const InitiateMongoServer = require('./envUtils/mongoDb.js')

const IN0429SourceFiles = require('./models/IN0429SourceFilesModel.js');

async function FileProcess(){
  await InitiateMongoServer();

const connSettings = {
  host: 'ITSUSRALSP01269.jnj.com',
  port: 22,
  username: 'btbcanftp',
  password: 'Welcome2016#',
};

const remotePaths = [
  '/data/interface/P50CLNT100/outbound/IN0429/',
  '/data/interface/P50CLNT100/archive/IN0429/',
];

const conn = new Client();
const dataToInsert = [];

// mongoose.connect('mongodb://localhost:27017/processFlow', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });


async function processFilesInPath(remotePath) {
  try {
    await new Promise((resolve, reject) => {
      conn.sftp((err, sftp) => {
        if (err) reject(err);

        sftp.readdir(remotePath, (err, list) => {
          if (err) reject(err);

          for (const file of list) {
            if (file.filename.startsWith('IN0429_BtBECC')) {
              var filename = '';
              var filesize = '';
              var date = '';
              var time = '';
              const timeRegex = /\b(\d{2}:\d{2})\b/;
              const match = file.longname.match(timeRegex);
              if (match) {
                time = match[1];
              }

              filename = file.filename.substring(0, 36);
              filesize = (file.attrs.size / 1024).toFixed(2);

              timestamp = file.filename.substring(18, 32);
              date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');

            

              if (filename) {
                dataToInsert.push({
                  filename: filename,
                  FileSize: filesize,
                  Date: date,
                  Time: time,
                });
              }
            }
          }

          resolve();
        });
      });
    });
  } catch (error) {
    console.error(`Error reading directory ${remotePath}: ${error.message}`);
  }
}

let newInsertions = 0;
let skippedEntries = 0;

conn.on('ready', async function () {
  // Loop through each remote path
  for (const remotePath of remotePaths) {
    await processFilesInPath(remotePath);
  }

  // Insert data into the MongoDB collection
  try {
    for (const entry of dataToInsert) {
      // Check if the entry already exists in the collection
      const existingEntry = await IN0429SourceFiles.findOne({ filename: entry.filename });
     
      if (!existingEntry) {
        // If the entry does not exist, insert it into the collection
        await IN0429SourceFiles.create(entry);
        
      }
    }

    
  } catch (error) {
    console.error(`Error inserting data into MongoDB: ${error.message}`);
  }

  conn.end();
 
  console.log('Connections closed successfully.');
});

conn.connect(connSettings);
}
FileProcess();
// // Schedule the cron job to run daily at 5 pm (17:00)
// cron.schedule('22 11 * * *', async () => {
//   console.log('Running the cron job at 11 am...');
//   await FileProcess();
// });

// // Schedule the cron job to run at 3 pm
// cron.schedule('31 12 * * *', () => {
//   console.log('Running the cron job at 3 pm...');
//   FileProcess();
// });

// // Schedule the cron job to run at 9 pm
// cron.schedule('0 21 * * *', () => {
//   console.log('Running the cron job at 9 pm...');
//   FileProcess();
// });
