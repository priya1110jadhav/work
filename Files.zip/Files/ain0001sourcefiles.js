const { Client } = require('ssh2');
const moment = require('moment');
const mongoose = require('mongoose');
const cron = require('node-cron');
const InitiateMongoServer = require('./envUtils/mongoDb.js')
const AIN0001SourceFiles = require('./models/AIN0001SourceFilesModel.js');

async function FileProcess() {
   await InitiateMongoServer();
  const connSettings = {
    host: 'itsusral00563.jnj.com',
    port: 22,
    username: 'sg910btb',
    password: 'passw0rd@BTB',
  };

  const remotePaths = [
    '/opt/btb/appdata/MDD/MG890_APO/FFOutbound/AIN0001/GMED812/Archive/',
    '/opt/btb/appdata/MDD/MG890_APO/FFOutbound/AIN0001/LEAPLIVE/Archive/',
    '/opt/btb/appdata/MDD/MG890_APO/FFOutbound/AIN0001/USROTC/Archive/',
    '/opt/btb/appdata/MDD/MG890_APO/FFOutbound/AIN0001/GMED812/Outbound/',
    '/opt/btb/appdata/MDD/MG890_APO/FFOutbound/AIN0001/LEAPLIVE/Outbound/',
    '/opt/btb/appdata/MDD/MG890_APO/FFOutbound/AIN0001/USROTC/Outbound/',
  ];

  const csvFilePath = 'source.csv'; // Change this to your desired CSV file path

  const conn = new Client();
  const dataToInsert = [];

  // mongoose.connect('mongodb://localhost:27017/processFlow', {
  //   useNewUrlParser: true,
  //   useUnifiedTopology: true,
  // });

  // const ain0001SourceFileSchema = new mongoose.Schema({
  //   filename: String,
  //   FileSize: String,
  //   Date: String,
  //   Time: String,
  // });

  // const AIN0001SourceFiles = mongoose.model('ain0001sourcefiles', ain0001SourceFileSchema);

  async function processFilesInPath(remotePath) {
    try {
      await new Promise((resolve, reject) => {
        conn.sftp((err, sftp) => {
          if (err) reject(err);

          sftp.readdir(remotePath, (err, list) => {
            if (err) reject(err);

            for (const file of list) {
              if (file.filename.startsWith('AIN0001_CUSTOMER_ORDERS_DP')) {
                var filename = '';
                var filesize = '';
                var date = '';
                var time = '';
                var timestamp = '';
                if (file.filename.includes('GMED812_CDL')) {
                  filename = file.filename.substring(0, 57);
                  filesize = (file.attrs.size / 1024).toFixed(2);

                  timestamp = file.filename.substring(39, 53);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  time = moment(timestamp, 'YYYYMMDDHHmmss').format('HH:mm:ss');
                } else if (file.filename.includes('GMED812')) {
                  filename = file.filename.substring(0, 53);
                  filesize = (file.attrs.size / 1024).toFixed(2);

                  timestamp = file.filename.substring(35, 50);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  time = moment(timestamp, 'YYYYMMDDHHmmss').format('HH:mm:ss');
                } else if (file.filename.includes('LEAPLIVE')) {
                  filename = file.filename.substring(0, 51);
                  filesize = (file.attrs.size / 1024).toFixed(2);

                  timestamp = file.filename.substring(36, 51);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  time = moment(timestamp, 'YYYYMMDDHHmmss').format('HH:mm:ss');
                } else if (file.filename.includes('USROTC')) {
                  if (file.filename.includes('COD') || file.filename.includes('MTK') || file.filename.includes('SPN')) {
                    filename = file.filename.substring(0, 56);
                    filesize = (file.attrs.size / 1024).toFixed(2);

                    timestamp = file.filename.substring(38, 52);
                    date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                    time = moment(timestamp, 'YYYYMMDDHHmmss').format('HH:mm:ss');
                  } 
                  else {
                    filename = file.filename.substring(0, 58);
                    filesize = (file.attrs.size / 1024).toFixed(2);

                    timestamp = file.filename.substring(40, 54);
                    date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                    time = moment(timestamp, 'YYYYMMDDHHmmss').format('HH:mm:ss');
                  }
                }

                dataToInsert.push({
                  filename: filename,
                  FileSize: filesize,
                  Date: date,
                  Time: time,
                });
              }
            }

            resolve();
          });
        });
      });
    } catch (error) {
      console.error(`Error reading directory ${remotePath}: ${error.message}`);
    }
  }

  async function insertDataIntoMongoDB() {
    let newInsertions = 0;
    let skippedEntries = 0;

    try {
      for (const entry of dataToInsert) {
        const existingEntry = await AIN0001SourceFiles.findOne({ filename: entry.filename });

        
        if (!existingEntry) {
          await AIN0001SourceFiles.create(entry);


        }
      }

    } catch (error) {
      console.error(`Error inserting data into MongoDB: ${error.message}`);
    } 
  }

  conn.on('ready', async function () {
    for (const remotePath of remotePaths) {
      await processFilesInPath(remotePath);
    }

    await insertDataIntoMongoDB();

    conn.end();
    // mongoose.disconnect();
    console.log('Connections closed successfully.');
  });

  conn.connect(connSettings);
}
// Schedule the cron job to run daily at 5 pm (17:00)
cron.schedule('01 11 * * *', async () => {
  console.log('Running the cron job at 11 am...');
  await FileProcess();
});

// Schedule the cron job to run at 3 pm
cron.schedule('10 20 * * *', () => {
  console.log('Running the cron job at 8:9 pm...');
  FileProcess();
});
// Schedule the cron job to run at 9 pm
cron.schedule('05 20 * * *', () => {
  console.log('Running the cron job at 8.5 pm...');
  FileProcess();
});