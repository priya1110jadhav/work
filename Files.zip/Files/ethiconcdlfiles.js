const fs = require('fs');
const { Client } = require('ssh2');
const moment = require('moment');
const mongoose = require('mongoose');
const axios = require('axios');
const cron = require('node-cron');
const InitiateMongoServer = require('./envUtils/mongoDb.js');
const APOBWDATFiles = require('./models/APOBWDATFilesModel.js');

async function FileProcess() {
  await InitiateMongoServer();
  const connSettings = {
    host: 'ITSUSRALSP00875.jnj.com',
    port: 22,
    username: 'btbcanftp',
    password: 'Welcome2016#',
  };

  const remotePaths = [
    '/data/interface/BPUCLNT400/out/IN0428/',
    '/data/interface/BPUCLNT400/archive/IN0428/',
    '/data/interface/BPUCLNT400/archive/IN0589/',
    '/data/interface/BPUCLNT400/archive/IN0565/',
    '/data/interface/BPUCLNT400/archive/IN0669',
    '/data/interface/BPUCLNT400/archive/IN0831/'
  ];

  const conn = new Client();
  const dataToInsert = [];
  
  async function processFilesInPath(remotePath) {
    try {
      await new Promise((resolve, reject) => {
        conn.sftp((err, sftp) => {
          if (err) reject(err);

          sftp.readdir(remotePath, (err, list) => {
            if (err) reject(err);

            for (const file of list) {
              if (file.filename) {
                let filename = file.filename;
                let filesize = (file.attrs.size / 1024).toFixed(2);
                let date = '';
                let time = '';
                
                const timeRegex = /\b(\d{2}:\d{2})\b/;
                const match = file.longname.match(timeRegex);
                if (match) {
                  time = match[1];
                }

                let year = '';
                if (file.filename.startsWith("B11")) {
                  year = file.filename.substring(11, 15);
                } else if (file.filename.startsWith("EES_FCST")) {
                  year = file.filename.substring(21, 25);
                } else if (file.filename.startsWith("EES_SCORE_FCST")) {
                  year = file.filename.substring(27, 31);
                } else if (file.filename.startsWith("EES_SCORE_DMND")) {
                  year = file.filename.substring(27, 31);
                } else if (file.filename.startsWith("Sales_Order_Lines_History")) {
                  year = file.filename.substring(32, 36);
                } else if (file.filename.startsWith("DemandHistoryCA")) {
                  year = file.filename.substring(22, 26);
                } else if (file.filename.startsWith("IN0831_FORECAST_LEAPLIVE")) {
                  year = file.filename.substring(23, 27);
                }

                const longnameParts = file.longname.split(/\s+/);
                const month = longnameParts[5];
                const day = longnameParts[6];

                // Combine the extracted year, month, and day
                const formattedDate = moment(`${month} ${day} ${year}`, 'MMM D YYYY').format('M/D/YYYY');

                console.log("filedate",filename, formattedDate);
                // Push data for insertion
                if (filename) {
                  dataToInsert.push({
                    filename: filename,
                    FileSize: filesize,
                    Date: formattedDate,
                    Time: time,
                  });
                }
              }
            }

            resolve();
          });
        });
      });
    } catch (error) {
      console.error(`Error reading directory ${remotePath}: ${error.message}`);
    }
  }

  conn.on('ready', async function () {
    for (const remotePath of remotePaths) {
      await processFilesInPath(remotePath);
    }

    try {
      for (const entry of dataToInsert) {
        console.log(`Updating date for ${entry.filename}: ${entry.Date}`);

        // Check if the entry already exists in the collection
        const existingEntry = await APOBWDATFiles.findOne({ filename: entry.filename });

        if (existingEntry) {
          await APOBWDATFiles.updateMany({ filename: entry.filename }, { $set: { Date: entry.Date } });
        } else {
          await APOBWDATFiles.create(entry);
        }
      }
    } catch (error) {
      console.error(`Error inserting data into MongoDB: ${error.message}`);
    }

    conn.end();
    console.log('Connections closed successfully.');
  });

  conn.connect(connSettings);
}

FileProcess();
