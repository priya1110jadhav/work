/**
 * Module dependencies.
 */
const mongoose = require('mongoose');
// import mongoose from 'mongoose';
const { getConnectionOptions, getConnectionString } = require('./mongoHelper');
// const getConnectionOptions
let mongooseConn;

//InitiateMongoServer will be use to establish connection with mongodb
const InitiateMongoServer = async () => {
  try {
    if (!mongooseConn) {
      if (process.env.NODE_ENV === 'test') return mongooseConn;
      let connectionString = await getConnectionString();
      const options = await getConnectionOptions();
      mongooseConn = await mongoose.connect(`mongodb://${connectionString}`, options);
    }
    if (process.env.NODE_ENV.includes('dev') || process.env.NODE_ENV.includes('local')) 
      mongoose.set('debug', true);
    return mongooseConn;
  } catch (e) {
    throw e;
  }
};

/**
 * Exporting mongo connection function.
 */
module.exports = InitiateMongoServer;
