const { Client } = require('ssh2');
const moment = require('moment');
const mongoose = require('mongoose');
const axios = require('axios');
const cron = require('node-cron');
const InitiateMongoServer = require('./envUtils/mongoDb.js');
const AIN0001TargetFiles = require('./models/AIN0001TargetFilesModel.js');

async function FileProcess(){
  await InitiateMongoServer();
const connSettings = {
  host: 'ITSUSRALSP00874.jnj.com',
  port: 22,
  username: 'wmpftp',
  password: 'Wmpftp@13',
};

const remotePaths = [
  '/data/interface/BPUCLNT400/archive/ACO0002/',
  '/data/interface/BPUCLNT400/in/ACO0002/'
];
try{
// mongoose.connect('mongodb://localhost:27017/processFlow', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });


const conn = new Client();
const dataToInsert = [];

const checkTime = (file) => {
 
  const fileTime = moment(file.Time, 'HH:mm:ss');
  let result = 'Delayed'; // Default result

  if (file.filename.includes('GMED812')) {
    const startOfDay = moment(fileTime).startOf('day');
    const timeDiff = moment.duration(fileTime.diff(startOfDay)).asMinutes();

    // GMED812 files come within first 5 mins for every 3 hours
    if (timeDiff % 180 <= 5) {
      result = 'Success';
    }
  } else if (file.filename.includes('LEAPLIVE2')) {
    // LEAPLIVE2 files come between 10:45 am to 11 am
    const startTime = moment().set({ hour: 10, minute: 45, second: 0 });
    const endTime = moment().set({ hour: 11, minute: 0, second: 0 });

    if (fileTime.isBetween(startTime, endTime) || fileTime.isBefore(endTime)) {
      result = 'Success';
    }
  } else if (file.filename.includes('USROTC_MTK')) {
    // USROTC_MTK files come between 1 am to 2 am
    const startTime = moment().set({ hour: 1, minute: 0, second: 0 });
    const endTime = moment().set({ hour: 2, minute: 0, second: 0 });

    if (fileTime.isBetween(startTime, endTime)|| fileTime.isBefore(endTime)) {
      result = 'Success';
    }
  } else if (file.filename.includes('USROTC_ORTHO')) {
    // USROTC_ORTHO files come between 5 am to 8 am
    const startTime = moment().set({ hour: 5, minute: 0, second: 0 });
    const endTime = moment().set({ hour: 8, minute: 0, second: 0 });

    if (fileTime.isBetween(startTime, endTime) || fileTime.isBefore(endTime)) {
      result = 'Success';
    }
  } else if (file.filename.includes('USROTC_SPN')) {
    // USROTC_SPN files come between 00:00 am to 1:30 am
    const startTime = moment().set({ hour: 0, minute: 0, second: 0 });
    const endTime = moment().set({ hour: 1, minute: 30, second: 0 });

    if (fileTime.isBetween(startTime, endTime)|| fileTime.isBefore(endTime)) {
      result = 'Success';
    }
  } else if (file.filename.includes('USROTC_COD')) {
    // USROTC_COD files come between 23:00 pm to 00:30 am
    const startTime = moment().set({ hour: 23, minute: 0, second: 0 });
    const endTime = moment().set({ hour: 0, minute: 30, second: 0 }).add(1, 'day');

    if (fileTime.isBetween(startTime, endTime) || fileTime.isBefore(endTime)) {
      result = 'Success';
    }
  }

  

  return result;
};
async function processFilesInPath(remotePath) {
  try {
    await new Promise((resolve, reject) => {
      conn.sftp((err, sftp) => {
        if (err) reject(err);

        sftp.readdir(remotePath, (err, list) => {
          if (err) reject(err);

          for (const file of list) {
            if (file.filename.startsWith('AIN0001_CUSTOMER_ORDERS_DP')) {
              var filename = '';
              var filesize = '';
              var date = '';
              var time = '';
              var timestamp = '';
              const timeRegex = /\b(\d{2}:\d{2})\b/;
              const match = file.longname.match(timeRegex);
              if (match) {
                time = match[1];
              }

              if (file.filename.includes('GMED812') && !file.filename.includes('GMED812_CDL')) {
                filename = file.filename.substring(0, 53);
                filesize = (file.attrs.size / 1024).toFixed(2);
                timestamp = file.filename.substring(35, 50);
                date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY'); // Format changed here

              } else if (file.filename.includes('LEAPLIVE')) {
                filename = file.filename.substring(0, 51);
                filesize = (file.attrs.size / 1024).toFixed(2);
                timestamp = file.filename.substring(36, 51);
                date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY'); // Format changed here
              } else if (file.filename.includes('USROTC')) {
                if (file.filename.includes('COD') || file.filename.includes('MTK') || file.filename.includes('SPN')) {
                  filename = file.filename.substring(0, 56);
                  filesize = (file.attrs.size / 1024).toFixed(2);
                  timestamp = file.filename.substring(38, 52);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY'); // Format changed here
                } else {
                  filename = file.filename.substring(0, 58);
                  filesize = (file.attrs.size / 1024).toFixed(2);
                  timestamp = file.filename.substring(40, 54);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY'); // Format changed here
                }
              }

             

              var fileStatus = checkTime({filename: filename,
                      FileSize: filesize,
                      Date: date,
                      Time: time,});
              
              if (filename) {
                dataToInsert.push({
                    filename: filename,
                    FileSize: filesize,
                    Date: date,
                    Time: time,
                       fileStatus: fileStatus,
                    msg: null
                });
              }

              
            }
          }

          resolve();
        });
      });
    });
  } catch (error) {
    console.error(`Error reading directory ${remotePath}: ${error.message}`);
  }
}

// async function fetchDataAndUpdate() {
//   let config = {
//     method: 'get',
//     maxBodyLength: Infinity,
//     url: 'https://mboxispv.na.jnj.com:5503/rest/SG001_SDX_UI/http/SG001_MBOX_UI.api2.documents:selectDocuments?^$json=%7B%22projectId%22:null,%22hours%22:%22-24%22,%22fromDateTime%22:null,%22toDateTime%22:null,%22processed%22:null,%22fileDefinitionId%22:null,%22fileDefinitionName%22:null,%22filename%22:null,%22hostid%22:null,%22minimumNumberOfTries%22:0,%22offset%22:0,%22limit%22:20,%22sortModel%22:%5B%7B%22sort%22:%22desc%22,%22colId%22:%22RECEIVED_DATETIME%22%7D%5D%7D',
//     headers: { 
//       'Accept': 'application/json, text/plain, */*', 
//       'Accept-Language': 'en-US,en;q=0.9', 
//       'Authorization': 'Basic cGphZGhhMjk6U2hpbmRlKSg6', 
//       'Connection': 'keep-alive', 
//       'If-Modified-Since': 'Mon, 18 Dec 2023 05:36:43 GMT', 
//       'If-None-Match': '"oSdYTdbWn62/4eNNSy1zQ53iMx5KEbi/h3y+2GFJp4w="', 
//       'Referer': 'https://mboxispv.na.jnj.com:5503/SG001_MBOX_UI/', 
//       'Sec-Fetch-Dest': 'empty', 
//       'Sec-Fetch-Mode': 'cors', 
//       'Sec-Fetch-Site': 'same-origin', 
//       'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 
//       'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"', 
//       'sec-ch-ua-mobile': '?0', 
//       'sec-ch-ua-platform': '"Windows"', 
//       'Cookie': 'ssnid=e90924b9bc0c41da944b80e51d4b1a13'
//     }
//   };
//       try {
//         const response = await axios.request(config);
//         const resultsArray = response.data.results;
        
//         // Filter only the files starting with 'IN0429_BtBECC_908'
//         const filteredResults = resultsArray.filter(({ FILENAME }) => FILENAME.startsWith('AIN0001_CUSTOMER_ORDERS_DP'));
        
//         // Create the selectedResults array
//         const selectedResults = filteredResults.map(({ FILENAME, MSG }) => ({
//           filename: FILENAME,
//           msg: MSG,
//         })); 
        
    
//         // Iterate through selectedResults
//         for (const entry of selectedResults) {
            

            
//           // Check if the entry already exists in the collection
         
//           const existingEntry = await AIN0001TargetFiles.findOne({ filename: entry.filename });
    
         
//           if(existingEntry !== null){

          
          
//             // If the entry exists and msg is not present, update the 'msg' field
//             if (existingEntry.msg === null) {
                
//               await AIN0001TargetFiles.updateOne({ filename: entry.filename }, { msg: entry.msg });
             
//             }
        
//         }
          
//         }
    
//         console.log('Database msg operation completed.');
//       } catch (error) {
//         console.log(error);
//       }

// }
async function insertDataIntoMongoDB() {
  let newInsertions = 0;
  let skippedEntries = 0;

  try {
    for (const entry of dataToInsert) {
      const existingEntry = await AIN0001TargetFiles.findOne({ filename: entry.filename });
      // await AIN0001TargetFiles.updateOne({ filename: entry.filename }, { $set: { fileStatus: entry.fileStatus } });
      if (!existingEntry) {
        await AIN0001TargetFiles.create(entry);
        
        newInsertions++;
      } else {
        
        skippedEntries++;
      }
    }

  } catch (error) {
    console.error(`Error inserting data into MongoDB: ${error.message}`);
  }
}

conn.on('ready', async function () {
  for (const remotePath of remotePaths) {
    await processFilesInPath(remotePath);
  }

  await insertDataIntoMongoDB();
  // await fetchDataAndUpdate();

  conn.end(); // Close SSH connection
  // mongoose.disconnect(); 
  console.log('Connections closed successfully.');
});

conn.connect(connSettings);
}catch (error) {
  console.error('Error:', error.message);
  // mongoose.disconnect(); 
  console.log('MongoDB connection closed due to error.');
}
}
FileProcess();

// // Schedule the cron job to run daily at 5 pm (17:00)
// cron.schedule('58 10 * * *', async () => {
//   console.log('Running the cron job at 11 am...');
//   await FileProcess();
// });

// // Schedule the cron job to run at 3 pm
// cron.schedule('21 12 * * *', () => {
//   console.log('Running the cron job at 3 pm...');
//   FileProcess();
// });

// // Schedule the cron job to run at 9 pm
// cron.schedule('0 21 * * *', () => {
//   console.log('Running the cron job at 9 pm...');
//   FileProcess();
// });