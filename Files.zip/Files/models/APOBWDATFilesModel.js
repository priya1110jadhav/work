// models/sourcefiles.js
const mongoose = require('mongoose');

const APOBWDATFilesSchema = new mongoose.Schema({
  filename: String,
  FileSize: String, 
  Date: String,
  Time: String,
});

const APOBWDATFiles = mongoose.model('apobwdatfiles', APOBWDATFilesSchema);

module.exports = APOBWDATFiles;