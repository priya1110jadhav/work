// models/sourcefiles.js
const mongoose = require('mongoose');

const EthiconCDLFilesSchema = new mongoose.Schema({
  filename: String,
  FileSize: String, 
  Date: String,
  Time: String,
});

const EthiconCDLFiles = mongoose.model('ethiconcdlfiles', EthiconCDLFilesSchema);

module.exports = EthiconCDLFiles;