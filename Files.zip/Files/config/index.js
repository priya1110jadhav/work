const APP_CONFIG = {
    MONGO: {
      OPTIONS: {
        useUnifiedTopology: true,
        useNewUrlParser: true,
      },
      HOST: process.env.MONGO_HOST,
      PORT: process.env.MONGO_PORT,
      USERNAME: process.env.MONGO_USERNAME,
      PASSWORD: process.env.MONGO_PASSWORD,
      PASSWORD_PARAM: process.env.MONGO_PASSWORD_PARAM,
      DATABASE: 'visualization-ms',
      MONGODB_CONNECTION_URL: process.env.MONGO_CONNECTION_URL,
    } 
  };
  
  
  module.exports = {
    APP_CONFIG
  };
  