const fs = require('fs');
const path = require('path');
const { APP_CONFIG } = require('../config');
const { getMongoPassword, getMongoPem, getMongoLdapString } = require('./envUtils');

const getConnectionString = async database => {
  let connectionString;
  const dbName = database ? database : APP_CONFIG.MONGO.DATABASE;
  console.log(process.env.LDAP_ENABLED_MONGO_CONN, process.env.NODE_ENV.toLowerCase());
  if (process.env.LDAP_ENABLED_MONGO_CONN === process.env.NODE_ENV.toLowerCase()) {
    const ldapString = process.env.MONGO_LDAP_LOCAL_URL ? process.env.MONGO_LDAP_LOCAL_URL : await getMongoLdapString();
    connectionString = `${ldapString}/${dbName}?authMechanism=SCRAM-SHA-256&authSource=admin&replicaSet=risesbx`;
  } else {
    const mongoPassword = process.env.MONGO_PASSWORD ? process.env.MONGO_PASSWORD : await getMongoPassword();
    connectionString = `${APP_CONFIG.MONGO.USERNAME}:${encodeURIComponent(mongoPassword)}@${APP_CONFIG.MONGO.HOST}:${APP_CONFIG.MONGO.PORT}/${dbName}?authSource=admin`;
  }
  return connectionString;
};

const getConnectionOptions = async () => {
  if (process.env.MONGO_TLS_ENABLED !== 'false') {
    APP_CONFIG.MONGO.OPTIONS.tls = true;
    const filePath = path.join(__dirname, '../', 'mongo-ca.pem');
    if (fs.existsSync(filePath)) {
      APP_CONFIG.MONGO.OPTIONS.tlsCAFile = filePath;
    } else {
      fs.writeFileSync(filePath, await getMongoPem());
      APP_CONFIG.MONGO.OPTIONS.tlsCAFile = filePath;
    }
  }
  return APP_CONFIG.MONGO.OPTIONS;
};

module.exports = { getConnectionString, getConnectionOptions };