// models/sourcefiles.js
const mongoose = require('mongoose');

const IN0429TargetFilesSchema = new mongoose.Schema({
  filename: String,
  FileSize: String,
  Date: String,
  Time: String,
  fileStatus: String,
  msg: String,
  // Other fields if needed
});

const IN0429TargetFiles = mongoose.model('in0429targetfiles', IN0429TargetFilesSchema);

module.exports = IN0429TargetFiles;