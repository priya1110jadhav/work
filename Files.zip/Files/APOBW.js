const fs = require('fs');
const { Client } = require('ssh2');
const moment = require('moment');
const mongoose = require('mongoose');
const axios = require('axios');
const cron = require('node-cron');
const InitiateMongoServer = require('./envUtils/mongoDb.js')
const APOBWDATFiles = require('./models/APOBWDATFilesModel.js');

async function FileProcess() {
  await InitiateMongoServer();
  const connSettings = {
    host: 'ITSUSRALSP00875.jnj.com',
    port: 22,
    username: 'btbcanftp',
    password: 'Welcome2016#',
  };

  const remotePaths = [
    '/data/interface/BPUCLNT400/out/IN0428/',
    '/data/interface/BPUCLNT400/archive/IN0428/',
    '/data/interface/BPUCLNT400/archive/IN0589/',
    '/data/interface/BPUCLNT400/archive/IN0565/',
    '/data/interface/BPUCLNT400/archive/IN0669',
    '/data/interface/BPUCLNT400/archive/IN0831/'
  ];

  const conn = new Client();
  const dataToInsert = [];
  async function processFilesInPath(remotePath) {
    try {
      await new Promise((resolve, reject) => {
        conn.sftp((err, sftp) => {
          if (err) reject(err);

          sftp.readdir(remotePath, (err, list) => {
            if (err) reject(err);

            for (const file of list) {
              
              if (file.filename) {

                var filename = '';
                var filesize = '';
                var date = '';
                var time = '';
                const timeRegex = /\b(\d{2}:\d{2})\b/;
                const match = file.longname.match(timeRegex);
                if (match) {
                  time = match[1];
                }

                filename = file.filename;
                //   filename = file.filename.substring(0, 11);
                filesize = (file.attrs.size / 1024).toFixed(2);
                if (file.filename.startsWith("B11")) {
                  timestamp = file.filename.substring(11, 19);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                }
                else if (file.filename.startsWith("EES_FCST")) {

                  timestamp = file.filename.substring(21, 29);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');

                }
                else if (file.filename.startsWith("EES_SCORE_FCST")) {
                  // console.log("file", file.filename);
                  timestamp = file.filename.substring(27, 35);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  // console.log("date", timestamp,date);
                }
                else if (file.filename.startsWith("EES_SCORE_DMND")) {
                  // console.log("file", file.filename);
                  timestamp = file.filename.substring(27, 35);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  // console.log("date", timestamp,date);
                }
                else if (file.filename.startsWith("Sales_Order_Lines_History")) {
                  // console.log("file", file.filename);
                  timestamp = file.filename.substring(32, 40);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  // console.log("date", timestamp,date);
                }
                else if (file.filename.startsWith("DemandHistoryCA")) {
                  
                  timestamp = file.filename.substring(22, 30);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  
                }
                else if (file.filename.startsWith("IN0831_FORECAST_LEAPLIVE")) {
                  // console.log("file", file.filename);
                  timestamp = file.filename.substring(23, 32);
                  date = moment(timestamp, 'YYYYMMDD').format('M/D/YYYY');
                  console.log("date", timestamp,date);
                }



                if (filename) {
                  dataToInsert.push({
                    filename: filename,
                    FileSize: filesize,
                    Date: date,
                    Time: time,
                  });
                }
              }
            }

            resolve();
          });
        });
      });
    } catch (error) {
      console.error(`Error reading directory ${remotePath}: ${error.message}`);
    }
  }


  let newInsertions = 0;
  let skippedEntries = 0;

  conn.on('ready', async function () {
    // Loop through each remote path
    for (const remotePath of remotePaths) {
      await processFilesInPath(remotePath);
    }

    // Insert data into the MongoDB collection
    try {
      for (const entry of dataToInsert) {

        // Check if the entry already exists in the collection
        const existingEntry = await APOBWDATFiles.findOne({

          filename: entry.filename
        });
        await APOBWDATFiles.updateMany({ filename: entry.filename }, { $set: { Date: entry.Date } });




        if (!existingEntry) {
          // If the entry does not exist, insert it into the collection
          await APOBWDATFiles.create(entry);


        }
      }



    } catch (error) {
      console.error(`Error inserting data into MongoDB: ${error.message}`);
    }

    conn.end();

    console.log('Connections closed successfully.');
  });

  conn.connect(connSettings);
}
FileProcess();
// cron.schedule('34 17 * * *', async () => {
//   console.log('Running the cron job at 11 am...');
//   await FileProcess();
// });

// // Schedule the cron job to run at 3 pm
// cron.schedule('0 15 * * *', () => {
//   console.log('Running the cron job at 3 pm...');
//   FileProcess();
// });

// // Schedule the cron job to run at 9 pm
// cron.schedule('0 21 * * *', () => {
//   console.log('Running the cron job at 9 pm...');
//   FileProcess();
// });