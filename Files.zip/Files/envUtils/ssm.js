//ssm.js

"use strict";
const AWS = require("aws-sdk");

AWS.config.update({
  region: process.env.AWS_REGION, //us-east-1
});

const parameterStore = new AWS.SSM();
//function for fetching data from ssm parameter store
const getParameter = async (name) => {
  return parameterStore
    .getParameter({
      Name: name,
      WithDecryption: true,
    })
    .promise();
};

//function to fetch individual parameter value
const getParam = async (paramName) => getParameter(paramName);

//exporting ssm module functions
module.exports = { getParam };
