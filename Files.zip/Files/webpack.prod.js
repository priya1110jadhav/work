const path = require("path");
const nodeExternals = require('webpack-node-externals')

const config = {
  entry: "./index.js",
  mode: "production",
  target:"node",
  module: {
    rules: [
      {
        exclude: /(node_modules)/,
        test: /\.(js|jsx)$/i,
        loader: "babel-loader"
      }
    ]
  },
  output: {
    path: path.resolve(__dirname, "dist-server"),
    publicPath:'/',
    filename:'[name].js',
    clean:true
  },
  externals: [nodeExternals()],
  plugins: []
};

module.exports = config;