//Import dependences
require('dotenv').config();

const { getParam } = require('./ssm.js');
const { APP_CONFIG } = require('../config/index.js');
//PASSWORD_PARAM
const getMongoPassword = async () => {
  const res = await getParam(process.env.MONGO_PASSWORD_PARAM);
  return res.Parameter.Value;
};

//oAuth Secret
const getOAuthSecret = async () => {
  const res = await getParam(process.env.OAUTH_SECRET_PARAM);
  return res.Parameter.Value;
};

/**
 * Function will return OAUTH_SECRET decrypted value
 */
const getOAuthClient = async () => {
  const res = await getParam(process.env.OAUTH_CLIENT_PARAM);
  return res.Parameter.Value;
};

/**
 * Function will return OAUTH_SECRET decrypted value
 */
const getJwtLoginSecret = async () => {
  const res = await getParam(process.env.JWT_LOGIN_SECRET_PARAM);
  return res.Parameter.Value;
};
/**
 * Function will return TLS Pem decrypted value
 */
const getMongoPem = async () => {
  console.log('process.env.MONGO_TLS_PEM_FILE)', process.env.MONGO_TLS_PEM_FILE);
  const res = await getParam(process.env.MONGO_TLS_PEM_FILE);
  return res?.Parameter?.Value;
};

const getMongoLdapString = async () => {
  const res = await getParam(APP_CONFIG.MONGO.MONGODB_CONNECTION_URL);
  return res?.Parameter?.Value;
};
// Exporting modules
module.exports = { getMongoPassword, getOAuthSecret, getOAuthClient, getJwtLoginSecret,getMongoPem,getMongoLdapString };
