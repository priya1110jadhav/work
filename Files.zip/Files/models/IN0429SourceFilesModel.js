// models/sourcefiles.js
const mongoose = require('mongoose');

const IN0429SourceFilesSchema = new mongoose.Schema({
  filename: String,
  FileSize: String,// Assuming you want to use Number for double values
  Date: String,
  Time: String,
  // Other fields if needed
});

const IN0429SourceFiles = mongoose.model('in0429sourcefiles', IN0429SourceFilesSchema);

module.exports = IN0429SourceFiles;